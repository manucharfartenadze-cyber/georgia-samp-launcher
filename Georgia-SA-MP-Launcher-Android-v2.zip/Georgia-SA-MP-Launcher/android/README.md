# Georgia SA-MP Launcher — Android v2

ეს არის Android launcher UI, რომელიც ჰგავს მოთხოვნილ SA-MP launcher-ს.

## ფუნქციები
- Georgian dark/orange UI
- Servers / Info / Settings ქვედა ნავიგაცია
- ნებისმიერი `IP:PORT` ფორმატის სერვერის დამატება
- Favorites-ის მსგავსი ლოკალური სია
- SA-MP UDP `i` query-ით Online და Players/Max Players შემოწმება
- PLAY ცდილობს `samp://IP:PORT` და შემდეგ `omp://IP:PORT` deep link-ს
- GitHub Actions-ით Debug APK build

## მნიშვნელოვანი
ეს პროექტი **არ შეიცავს GTA:SA-ს ან SA-MP native game client-ს**. PLAY იმუშავებს მაშინ, თუ ტელეფონში დაყენებული თავსებადი SA-MP/OMP Android client რეგისტრირებულია შესაბამის deep-link-ზე. სრულფასოვანი standalone client-ისთვის საჭიროა შესაბამისი native client/runtime და ლიცენზირებული game files.
