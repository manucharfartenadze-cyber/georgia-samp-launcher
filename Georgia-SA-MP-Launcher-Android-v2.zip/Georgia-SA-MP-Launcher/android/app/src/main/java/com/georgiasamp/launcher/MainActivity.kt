package com.georgiasamp.launcher

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("georgia_launcher", MODE_PRIVATE) }
    private val executor = Executors.newCachedThreadPool()
    private val servers = mutableListOf<Server>()
    private var currentPage = Page.SERVERS

    data class Server(val host: String, val port: Int, var name: String = "SA-MP Server", var players: Int = -1, var maxPlayers: Int = -1, var online: Boolean = false)
    enum class Page { INFO, SERVERS, SETTINGS }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        loadServers()
        findViewById<View>(R.id.navInfo).setOnClickListener { showPage(Page.INFO) }
        findViewById<View>(R.id.navServers).setOnClickListener { showPage(Page.SERVERS) }
        findViewById<View>(R.id.navSettings).setOnClickListener { showPage(Page.SETTINGS) }
        showPage(currentPage)
    }

    private fun loadServers() {
        val raw = prefs.getString("servers", "") ?: ""
        raw.split("|").filter { it.contains(":") }.forEach {
            val parts = it.split(":")
            if (parts.size == 2) parts[1].toIntOrNull()?.let { p -> servers.add(Server(parts[0], p)) }
        }
    }

    private fun persistServers() {
        prefs.edit().putString("servers", servers.joinToString("|") { "${it.host}:${it.port}" }).apply()
    }

    private fun showPage(page: Page) {
        currentPage = page
        content.removeAllViews()
        when (page) {
            Page.INFO -> buildInfo()
            Page.SERVERS -> buildServers()
            Page.SETTINGS -> buildSettings()
        }
    }

    private fun title(text: String, size: Float = 30f): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(0xFFFFFFFF.toInt()); setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(4, 10, 4, 6)
    }

    private fun orangeButton(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 16f; setTextColor(0xFFFFFFFF.toInt()); setAllCaps(false); background = getDrawable(R.drawable.bg_orange)
        setPadding(10, 0, 10, 0); setOnClickListener { onClick() }
    }

    private fun darkButton(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 15f; setTextColor(0xFFFFFFFF.toInt()); setAllCaps(false); background = getDrawable(R.drawable.bg)
        setOnClickListener { onClick() }
    }

    private fun buildInfo() {
        content.addView(title("GEORGIA SA-MP"))
        content.addView(title("LAUNCHER", 21f))
        addSpace(14)
        val hero = TextView(this).apply {
            text = "UNIVERSAL SERVER\nLAUNCHER\n\nშედი ნებისმიერ თავსებად SA-MP სერვერზე IP:PORT-ით."
            textSize = 24f; setTextColor(0xFFFFFFFF.toInt()); setPadding(10, 18, 10, 18)
        }
        content.addView(hero)
        val ip = EditText(this).apply { hint = "მაგ. 94.23.168.153:2150"; setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF7F8790.toInt()); background = getDrawable(R.drawable.bg); setPadding(16, 0, 16, 0) }
        content.addView(ip, LinearLayout.LayoutParams(-1, 58).apply { setMargins(0, 8, 0, 10) })
        content.addView(orangeButton("▶  PLAY SERVER") { connect(ip.text.toString().trim()) }, LinearLayout.LayoutParams(-1, 56))
        addSpace(16)
        content.addView(darkButton("＋ სერვერის დამატება") { showAddServerDialog() }, LinearLayout.LayoutParams(-1, 52))
    }

    private fun buildServers() {
        content.addView(title("სერვერები"))
        val sub = TextView(this).apply { text = "Favorites  •  Mobile  •  Hosted"; textSize = 15f; setTextColor(0xFF9AA4AE.toInt()); setPadding(4,0,4,12) }
        content.addView(sub)
        content.addView(orangeButton("＋ სერვერის დამატება") { showAddServerDialog() }, LinearLayout.LayoutParams(-1, 52).apply { setMargins(0,0,0,14) })
        if (servers.isEmpty()) {
            val empty = TextView(this).apply { text = "⭐ ჯერ სერვერი არ დაგიმატებია.\nდაამატე IP:PORT და შემდეგ დააჭირე PLAY-ს."; textSize = 17f; setTextColor(0xFF9AA4AE.toInt()); setPadding(10,30,10,30) }
            content.addView(empty); return
        }
        servers.forEach { addServerCard(it) }
    }

    private fun addServerCard(server: Server) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,14,16,14); background = getDrawable(R.drawable.bg_card) }
        val name = TextView(this).apply { text = server.name; textSize = 18f; setTextColor(0xFFFFFFFF.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) }
        val address = TextView(this).apply { text = "Address: ${server.host}:${server.port}"; textSize = 14f; setTextColor(0xFF9AA4AE.toInt()); setPadding(0,5,0,0) }
        val status = TextView(this).apply { text = "● შემოწმება..."; textSize = 14f; setTextColor(0xFFFFB000.toInt()); setPadding(0,3,0,8) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val play = orangeButton("▶ PLAY") { connect("${server.host}:${server.port}") }
        val del = darkButton("★") { servers.remove(server); persistServers(); showPage(Page.SERVERS) }
        row.addView(play, LinearLayout.LayoutParams(0,52,1f)); row.addView(del, LinearLayout.LayoutParams(58,52).apply { setMargins(8,0,0,0) })
        card.addView(name); card.addView(address); card.addView(status); card.addView(row)
        content.addView(card, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,0,0,10) })
        queryServer(server, status, name)
    }

    private fun queryServer(server: Server, status: TextView, name: TextView) {
        executor.execute {
            val info = SampQuery.query(server.host, server.port)
            runOnUiThread {
                if (info != null) {
                    server.online = true; server.players = info.players; server.maxPlayers = info.maxPlayers; server.name = info.hostname.ifBlank { server.name }
                    name.text = server.name
                    status.text = "● ONLINE    ${info.players}/${info.maxPlayers} players"
                    status.setTextColor(0xFF72FF4D.toInt())
                } else {
                    server.online = false
                    status.text = "● OFFLINE / ვერ მოიძებნა"
                    status.setTextColor(0xFFFF4D4D.toInt())
                }
            }
        }
    }

    private fun buildSettings() {
        content.addView(title("პარამეტრები"))
        addSetting("ჩათში დრო", false)
        addSetting("FPS Counter", true)
        addSetting("Voice Chat", true)
        addSetting("FastConnect", false)
        addSetting("Modification Mode", false)
        addSetting("System Keyboard", true)
        val info = TextView(this).apply { text = "\nGeorgia SA-MP Launcher\nUniversal server connector\nVersion 2.0"; textSize = 15f; setTextColor(0xFF9AA4AE.toInt()) }
        content.addView(info)
    }

    private fun addSetting(label: String, checked: Boolean) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(4,12,4,12) }
        val text = TextView(this).apply { this.text = label; textSize = 17f; setTextColor(0xFFFFFFFF.toInt()) }
        val sw = Switch(this).apply { isChecked = checked; buttonTintList = null }
        row.addView(text, LinearLayout.LayoutParams(0,56,1f)); row.addView(sw, LinearLayout.LayoutParams(60,56)); content.addView(row)
    }

    private fun addSpace(dp: Int) { content.addView(Space(this), LinearLayout.LayoutParams(1, (dp * resources.displayMetrics.density).toInt())) }

    private fun showAddServerDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30,10,30,0) }
        val input = EditText(this).apply { hint = "IP:PORT"; setSingleLine(true); setTextColor(0xFF111111.toInt()); hint = "მაგ. 94.23.168.153:2150" }
        box.addView(input)
        AlertDialog.Builder(this).setTitle("სერვერის დამატება").setView(box).setNegativeButton("გაუქმება", null).setPositiveButton("დამატება") { _, _ ->
            val value = input.text.toString().trim()
            parse(value)?.let { (h,p) -> if (servers.none { it.host == h && it.port == p }) { servers.add(Server(h,p)); persistServers(); showPage(Page.SERVERS) } }
        }.show()
    }

    private fun parse(v: String): Pair<String, Int>? {
        val parts = v.trim().split(":")
        if (parts.size != 2) return null
        val port = parts[1].toIntOrNull() ?: return null
        if (port !in 1..65535 || parts[0].isBlank() || parts[0].contains(" ")) return null
        return parts[0] to port
    }

    private fun connect(value: String) {
        val parsed = parse(value) ?: run { Toast.makeText(this, "შეიყვანე სწორი IP:PORT", Toast.LENGTH_LONG).show(); return }
        val host = parsed.first; val port = parsed.second
        prefs.edit().putString("last", "$host:$port").apply()
        val uris = listOf("samp://$host:$port", "omp://$host:$port")
        var launched = false
        for (u in uris) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))); launched = true; break } catch (_: ActivityNotFoundException) { }
        }
        if (!launched) {
            AlertDialog.Builder(this).setTitle("SA-MP კლიენტი ვერ მოიძებნა")
                .setMessage("Launcher-მა სერვერი სწორად მიიღო: $host:$port\n\nტელეფონში საჭიროა თავსებადი SA-MP Android კლიენტი, რომელიც samp:// ან omp:// ბმულს ხსნის. მხოლოდ ეს launcher APK თავისით GTA:SA-ს ვერ გაუშვებს.")
                .setPositiveButton("გასაგებია", null).show()
        }
    }

    object SampQuery {
        data class Info(val players: Int, val maxPlayers: Int, val hostname: String)
        fun query(host: String, port: Int): Info? {
            return try {
                val ip = InetAddress.getByName(host)
                val sock = DatagramSocket(); sock.soTimeout = 1800
                val addr = ip.address
                val packet = ByteArray(11)
                packet[0]='S'.code.toByte(); packet[1]='A'.code.toByte(); packet[2]='M'.code.toByte(); packet[3]='P'.code.toByte()
                packet[4]=addr[0]; packet[5]=addr[1]; packet[6]=addr[2]; packet[7]=addr[3]
                packet[8]=(port and 0xFF).toByte(); packet[9]=((port shr 8) and 0xFF).toByte(); packet[10]='i'.code.toByte()
                sock.send(DatagramPacket(packet, packet.size, ip, port))
                val buf = ByteArray(4096); val resp = DatagramPacket(buf, buf.size); sock.receive(resp); sock.close()
                val d = resp.data; val len = resp.length
                if (len < 15 || String(d,0,4) != "SAMP") return null
                var o = 11
                val password = d[o].toInt() and 0xFF; o += 1
                val players = (d[o].toInt() and 0xFF) or ((d[o+1].toInt() and 0xFF) shl 8); o += 2
                val max = (d[o].toInt() and 0xFF) or ((d[o+1].toInt() and 0xFF) shl 8); o += 2
                fun readString(): String { if (o+2 > len) return ""; val n=(d[o].toInt() and 0xFF) or ((d[o+1].toInt() and 0xFF) shl 8); o+=2; if (n<=0 || o+n>len) return ""; val s=String(d,o,n,Charsets.UTF_8); o+=n; return s }
                Info(players,max,readString())
            } catch (_: Exception) { null }
        }
    }
}
