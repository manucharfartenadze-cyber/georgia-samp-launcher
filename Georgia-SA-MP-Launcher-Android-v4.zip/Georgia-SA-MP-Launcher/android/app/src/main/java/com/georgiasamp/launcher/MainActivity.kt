package com.georgiasamp.launcher

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private lateinit var pageTitle: TextView
    private val prefs by lazy { getSharedPreferences("georgia_launcher", MODE_PRIVATE) }
    private val executor = Executors.newCachedThreadPool()
    private val servers = mutableListOf<Server>()
    private var page = Page.SERVERS
    private var serverTab = ServerTab.FAVORITES

    data class Server(
        val host: String,
        val port: Int,
        var name: String = "SA-MP Server",
        var players: Int = -1,
        var maxPlayers: Int = -1,
        var mode: String = "SA-MP",
        var online: Boolean = false
    )
    enum class Page { INFO, SERVERS, SETTINGS }
    enum class ServerTab { FAVORITES, MOBILE, HOSTED }

    private val orange = 0xFFFF6A00.toInt()
    private val white = 0xFFF7F7F7.toInt()
    private val muted = 0xFF9B9B9B.toInt()
    private val bg = 0xFF08090A.toInt()
    private val card = 0xFF121416.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        pageTitle = findViewById(R.id.pageTitle)
        loadServers()
        findViewById<View>(R.id.navInfo).setOnClickListener { showPage(Page.INFO) }
        findViewById<View>(R.id.navServers).setOnClickListener { showPage(Page.SERVERS) }
        findViewById<View>(R.id.navSettings).setOnClickListener { showPage(Page.SETTINGS) }
        showPage(Page.SERVERS)
    }

    private fun loadServers() {
        val raw = prefs.getString("servers", "") ?: ""
        raw.split("|").filter { it.contains(":") }.forEach { value ->
            val parts = value.split(":")
            if (parts.size == 2) parts[1].toIntOrNull()?.let { p -> servers.add(Server(parts[0], p)) }
        }
    }

    private fun persistServers() {
        prefs.edit().putString("servers", servers.joinToString("|") { "${it.host}:${it.port}" }).apply()
    }

    private fun showPage(p: Page) {
        page = p
        content.removeAllViews()
        when (p) {
            Page.INFO -> { pageTitle.text = "ინფორმაცია"; buildInfo() }
            Page.SERVERS -> { pageTitle.text = "სერვერები"; buildServers() }
            Page.SETTINGS -> { pageTitle.text = "პარამეტრები"; buildSettings() }
        }
        updateNav(p)
    }

    private fun updateNav(p: Page) {
        val colors = listOf(findViewById<TextView>(R.id.infoIcon), findViewById<TextView>(R.id.infoText), findViewById<TextView>(R.id.serversIcon), findViewById<TextView>(R.id.serversText), findViewById<TextView>(R.id.settingsIcon), findViewById<TextView>(R.id.settingsText))
        colors.forEach { it.setTextColor(muted) }
        when (p) {
            Page.INFO -> { findViewById<TextView>(R.id.infoIcon).setTextColor(orange); findViewById<TextView>(R.id.infoText).setTextColor(orange) }
            Page.SERVERS -> { findViewById<TextView>(R.id.serversIcon).setTextColor(orange); findViewById<TextView>(R.id.serversText).setTextColor(orange) }
            Page.SETTINGS -> { findViewById<TextView>(R.id.settingsIcon).setTextColor(orange); findViewById<TextView>(R.id.settingsText).setTextColor(orange) }
        }
    }

    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); setTypeface(null, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun orangeButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 16f; setTextColor(white); setAllCaps(false); background = getDrawable(R.drawable.bg_orange)
        setOnClickListener { onClick() }
    }

    private fun darkButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 15f; setTextColor(white); setAllCaps(false); background = getDrawable(R.drawable.bg)
        setOnClickListener { onClick() }
    }

    private fun buildInfo() {
        val logo = text("GEORGIA\nSA-MP", 40f, white, true).apply { setPadding(8, 18, 8, 4) }
        content.addView(logo)
        content.addView(text("LAUNCHER", 18f, orange, true).apply { setPadding(8, 0, 8, 18) })
        content.addView(text("UNIVERSAL SERVER LAUNCHER", 25f, white, true).apply { setPadding(8, 14, 8, 8) })
        content.addView(text("შედი ნებისმიერ თავსებად SA-MP სერვერზე IP:PORT-ით.", 17f, muted).apply { setPadding(8, 0, 8, 18) })
        val input = EditText(this).apply {
            hint = "IP:PORT  •  მაგ. 94.23.168.153:2150"; setTextColor(white); setHintTextColor(0xFF777777.toInt()); background = getDrawable(R.drawable.bg_card); setPadding(18, 0, 18, 0); setSingleLine(true)
        }
        content.addView(input, LinearLayout.LayoutParams(-1, 58).apply { setMargins(0, 8, 0, 10) })
        content.addView(orangeButton("▶  PLAY SERVER") { connect(input.text.toString().trim()) }, LinearLayout.LayoutParams(-1, 58))
        content.addView(darkButton("＋  სერვერის დამატება") { showAddServerDialog() }, LinearLayout.LayoutParams(-1, 54).apply { setMargins(0, 12, 0, 16) })
        content.addView(text("✓ ნებისმიერი IP:PORT\n✓ Favorites\n✓ Online მოთამაშეების რაოდენობა\n✓ SA-MP / OMP ბმულის გახსნა", 15f, muted).apply { setPadding(8, 8, 8, 8) })
    }

    private fun buildServers() {
        addServerTabs()
        content.addView(orangeButton("＋  სერვერის დამატება") { showAddServerDialog() }, LinearLayout.LayoutParams(-1, 52).apply { setMargins(0, 4, 0, 10) })
        if (servers.isEmpty()) {
            content.addView(text("⭐ ჯერ სერვერი არ დაგიმატებია.\n\nდააჭირე „სერვერის დამატება“-ს და შეიყვანე ნებისმიერი IP:PORT.\n\nმაგალითი: 94.23.168.153:2150", 17f, muted).apply { setPadding(12, 28, 12, 20) })
            return
        }
        servers.forEach { addServerRow(it) }
    }

    private fun addServerTabs() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, 8) }
        val fav = tabButton("★  Favorites", serverTab == ServerTab.FAVORITES)
        val mobile = tabButton("Mobile", serverTab == ServerTab.MOBILE)
        val hosted = tabButton("Hosted", serverTab == ServerTab.HOSTED)
        fav.setOnClickListener { serverTab = ServerTab.FAVORITES; showPage(Page.SERVERS) }
        mobile.setOnClickListener { serverTab = ServerTab.MOBILE; showPage(Page.SERVERS) }
        hosted.setOnClickListener { serverTab = ServerTab.HOSTED; showPage(Page.SERVERS) }
        row.addView(fav, LinearLayout.LayoutParams(0, 48, 1f)); row.addView(mobile, LinearLayout.LayoutParams(0, 48, 1f)); row.addView(hosted, LinearLayout.LayoutParams(0, 48, 1f))
        content.addView(row)
        val line = View(this).apply { setBackgroundColor(orange) }
        content.addView(line, LinearLayout.LayoutParams(-1, 2))
    }

    private fun tabButton(label: String, active: Boolean) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 15f; setTextColor(if (active) white else muted); setTypeface(null, if (active) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun addServerRow(server: Server) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(8, 13, 8, 13); background = getDrawable(R.drawable.bg_card) }
        val icon = text("▣", 30f, if (server.online) 0xFF63FF46.toInt() else orange).apply { gravity = Gravity.CENTER; setPadding(0, 0, 10, 0) }
        row.addView(icon, LinearLayout.LayoutParams(45, 65))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val name = text(server.name, 17f, white, true)
        val address = text("Address: ${server.host}:${server.port}", 13f, muted)
        val mode = text("Mode: ${server.mode}", 13f, muted)
        info.addView(name); info.addView(address); info.addView(mode)
        row.addView(info, LinearLayout.LayoutParams(0, 65, 1f))
        val players = text(if (server.players >= 0) "♙\n${server.players}/${server.maxPlayers}" else "♙\n—", 15f, orange, true).apply { gravity = Gravity.CENTER }
        row.addView(players, LinearLayout.LayoutParams(58, 65))
        row.setOnClickListener { showServerDialog(server) }
        content.addView(row, LinearLayout.LayoutParams(-1, 91).apply { setMargins(0, 0, 0, 1) })
        queryServer(server, name, icon, players)
    }

    private fun queryServer(server: Server, name: TextView, icon: TextView, players: TextView) {
        executor.execute {
            val info = SampQuery.query(server.host, server.port)
            runOnUiThread {
                if (info != null) {
                    server.online = true; server.players = info.players; server.maxPlayers = info.maxPlayers; server.name = info.hostname.ifBlank { server.name }; server.mode = info.mode.ifBlank { server.mode }
                    name.text = server.name; icon.setTextColor(0xFF63FF46.toInt()); players.text = "♙\n${info.players}/${info.maxPlayers}"; players.setTextColor(orange)
                } else {
                    server.online = false; icon.setTextColor(0xFF555555.toInt()); players.text = "♙\n—"; players.setTextColor(muted)
                }
            }
        }
    }

    private fun showServerDialog(server: Server) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 8, 28, 0) }
        box.addView(text(server.name, 21f, white, true).apply { setPadding(0, 0, 0, 12) })
        box.addView(text("IP: ${server.host}\nPort: ${server.port}\nPlayers: ${if (server.players >= 0) "${server.players}/${server.maxPlayers}" else "შემოწმება..."}\nMode: ${server.mode}", 16f, muted).apply { setPadding(0, 0, 0, 18) })
        val play = orangeButton("▶  თამაში") { connect("${server.host}:${server.port}") }
        box.addView(play, LinearLayout.LayoutParams(-1, 52).apply { setMargins(0, 0, 0, 8) })
        val fav = darkButton("★  Favorites-დან წაშლა") { servers.remove(server); persistServers(); showPage(Page.SERVERS) }
        box.addView(fav, LinearLayout.LayoutParams(-1, 50))
        AlertDialog.Builder(this).setView(box).setNegativeButton("დახურვა", null).show()
    }

    private fun buildSettings() {
        addSetting("ჩათში დრო", false); addSetting("FPS Counter", true); addSetting("Voice Chat", true); addSetting("FastConnect", false); addSetting("Modification Mode", false); addSetting("System Keyboard", true)
        content.addView(text("\nGeorgia SA-MP Launcher\nUniversal server connector\nVersion 2.0", 15f, muted).apply { setPadding(8, 18, 8, 8) })
    }

    private fun addSetting(label: String, checked: Boolean) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(8, 4, 8, 4) }
        row.addView(text(label, 17f, white), LinearLayout.LayoutParams(0, 58, 1f))
        row.addView(Switch(this).apply { isChecked = checked }, LinearLayout.LayoutParams(65, 58))
        content.addView(row)
    }

    private fun showAddServerDialog() {
        val input = EditText(this).apply { hint = "მაგ. 94.23.168.153:2150"; setSingleLine(true) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 6, 28, 0); addView(input, LinearLayout.LayoutParams(-1, 58)) }
        AlertDialog.Builder(this).setTitle("სერვერის დამატება").setView(box).setNegativeButton("გაუქმება", null).setPositiveButton("დამატება") { _, _ ->
            val parsed = parse(input.text.toString().trim())
            if (parsed == null) Toast.makeText(this, "შეიყვანე სწორი IP:PORT", Toast.LENGTH_LONG).show()
            else if (servers.none { it.host == parsed.first && it.port == parsed.second }) { servers.add(Server(parsed.first, parsed.second)); persistServers(); showPage(Page.SERVERS) }
        }.show()
    }

    private fun parse(value: String): Pair<String, Int>? {
        val parts = value.split(":")
        if (parts.size != 2) return null
        val port = parts[1].toIntOrNull() ?: return null
        if (parts[0].isBlank() || port !in 1..65535 || parts[0].contains(" ")) return null
        return parts[0] to port
    }

    private fun connect(value: String) {
        val parsed = parse(value) ?: run { Toast.makeText(this, "შეიყვანე სწორი IP:PORT", Toast.LENGTH_LONG).show(); return }
        val target = "${parsed.first}:${parsed.second}"
        prefs.edit().putString("last", target).apply()
        var launched = false
        listOf("samp://$target", "omp://$target").forEach { uri ->
            if (!launched) try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri))); launched = true } catch (_: ActivityNotFoundException) { }
        }
        if (!launched) AlertDialog.Builder(this).setTitle("SA-MP კლიენტი ვერ მოიძებნა").setMessage("სერვერი მიღებულია: $target\n\nტელეფონში საჭიროა თავსებადი SA-MP/OMP Android client, რომელიც ამ ბმულს ხსნის.").setPositiveButton("გასაგებია", null).show()
    }

    object SampQuery {
        data class Info(val players: Int, val maxPlayers: Int, val hostname: String, val mode: String)
        fun query(host: String, port: Int): Info? = try {
            val ip = InetAddress.getByName(host); DatagramSocket().use { sock ->
                sock.soTimeout = 1800
                val a = ip.address
                val packet = byteArrayOf('S'.code.toByte(),'A'.code.toByte(),'M'.code.toByte(),'P'.code.toByte(),a[0],a[1],a[2],a[3],(port and 255).toByte(),((port shr 8) and 255).toByte(),'i'.code.toByte())
                sock.send(DatagramPacket(packet, packet.size, ip, port))
                val buf = ByteArray(4096); val resp = DatagramPacket(buf, buf.size); sock.receive(resp)
                val d=resp.data; val len=resp.length; if(len<15 || String(d,0,4)!="SAMP") return null
                var o=11; o++
                val players=(d[o].toInt() and 255) or ((d[o+1].toInt() and 255) shl 8); o+=2
                val max=(d[o].toInt() and 255) or ((d[o+1].toInt() and 255) shl 8); o+=2
                fun read():String { if(o+2>len)return ""; val n=(d[o].toInt() and 255) or ((d[o+1].toInt() and 255) shl 8); o+=2; if(n<=0 || o+n>len)return ""; val s=String(d,o,n,Charsets.UTF_8); o+=n; return s }
                Info(players,max,read(),read())
            }
        } catch (_: Exception) { null }
    }
}
