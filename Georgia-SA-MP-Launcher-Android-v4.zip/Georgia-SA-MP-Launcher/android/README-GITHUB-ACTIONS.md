# Georgia SA-MP Launcher v4

This version fixes the Java/Kotlin JVM target mismatch by explicitly using JVM 17.

GitHub Actions build:
1. Put this Android project inside the repository as `Georgia-SA-MP-Launcher/android/`
   or keep the ZIP-based workflow.
2. Use JDK 17 and Gradle 8.10.2.
3. Run `gradle assembleDebug --no-daemon`.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

This is a launcher/handoff app, not the GTA:SA/SA-MP game client itself.
